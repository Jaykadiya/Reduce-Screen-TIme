package com.android.reducescreentime;

public class MyReceiver {
}
